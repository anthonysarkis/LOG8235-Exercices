// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

/**
 * 
 */

class SOFTDESIGNTRAINING_API SDTUtils
{
public:
    static bool Raycast(UWorld* uWorld, FVector sourcePoint, FVector targetPoint);
    static bool RaycastNavMesh(UWorld* uWorld, FVector sourcePoint, FVector targetPoint);
};
