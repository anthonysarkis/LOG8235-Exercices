// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "SoftDesignTraining.h"

void SoftDesignTrainingModuleImpl::StartupModule()
{

}

void SoftDesignTrainingModuleImpl::WorldTickStart(ELevelTick, float)
{

}

void SoftDesignTrainingModuleImpl::WorldBeginPlay()
{
}

void SoftDesignTrainingModuleImpl::WorldLogFrameStats(int64 Frame)
{
}

void SoftDesignTrainingModuleImpl::WorldCleanup(UWorld*, bool, bool)
{
}

void SoftDesignTrainingModuleImpl::ShutdownModule()
{

}


IMPLEMENT_PRIMARY_GAME_MODULE(SoftDesignTrainingModuleImpl, SoftDesignTraining, "SoftDesignTraining");

DEFINE_LOG_CATEGORY(LogSoftDesignTraining)
 