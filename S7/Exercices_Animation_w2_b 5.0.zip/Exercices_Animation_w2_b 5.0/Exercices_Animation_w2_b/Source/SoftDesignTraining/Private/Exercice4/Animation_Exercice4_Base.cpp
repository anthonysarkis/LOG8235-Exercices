#include "Exercice4/Animation_Exercice4_Base.h"
#include "SoftDesignTraining.h"
#include "DrawDebugHelpers.h"
#include "SDTUtils.h"
#include "EngineUtils.h"
#include "ReactionManager.h"

AAnimation_Exercice4_Base::AAnimation_Exercice4_Base() {
}

