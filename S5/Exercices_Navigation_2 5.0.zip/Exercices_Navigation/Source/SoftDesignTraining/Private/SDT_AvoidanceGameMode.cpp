// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "SDT_AvoidanceGameMode.h"
#include "SoftDesignTraining.h"

ASDTAvoidanceGameMode::ASDTAvoidanceGameMode()
{
}