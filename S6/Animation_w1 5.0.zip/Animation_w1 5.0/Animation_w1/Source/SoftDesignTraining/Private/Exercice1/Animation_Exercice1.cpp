#include "Exercice1/Animation_Exercice1.h"
#include "SoftDesignTraining.h"
#include "SDTUtils.h"

// UpdateNavigation_Exercice1
//
// deltaTime : The delta time for the frame 
// targetSpeed : The speed given to the actor by it's ai 

void AAnimation_Exercice1::UpdateNavigation_Exercice1(float deltaTime, float targetSpeed)
{

}
